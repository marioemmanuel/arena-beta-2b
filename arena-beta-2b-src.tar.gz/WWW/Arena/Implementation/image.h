#ifndef _ARENA_IMAGE_H_
#define _ARENA_IMAGE_H_

extern int Voltage2Brightness(int);
extern int Brightness2Voltage(int);

#endif /* _ARENA_IMAGE_H_ */
