/*                                                                 Presentation of Plain Text
                                    PLAIN TEXT OBJECT
                                             
 */
/*
**      (c) COPYRIGHT MIT 1995.
**      Please first read the full copyright statement in the file COPYRIGH.
*/
/*

   This module is implemented by HTPlain.c, and it is a part of the  W3C Reference
   Library.
   
 */
#ifndef HTPLAIN_H
#define HTPLAIN_H

#include "HTFormat.h"

extern HTConverter HTPlainPresent;

#endif
/*

   End of definition module.  */
