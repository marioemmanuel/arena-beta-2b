#include "WWWLib.h"
int main()
{
    HTLibInit("TestApp", "1.0");
    HTLibTerminate();
    return 0;
}
